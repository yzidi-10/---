import { useState } from "react";
import { L200Viewport3D } from "./components/L200Viewport3D";
import { ScientificInspector } from "./components/ScientificInspector";
import { FullBreakdownView } from "./components/FullBreakdownView";
import { ImageStudio } from "./components/ImageStudio";
import { PhysicsSpecsView } from "./components/PhysicsSpecsView";
import {
  AssemblyId,
  SCIENTIFIC_PARTS,
  ScientificPart,
} from "./data/l200Data";

type ViewTab = "3d" | "breakdown" | "studio" | "physics";

export default function App() {
  const [activeTab, setActiveTab] = useState<ViewTab>("3d");
  const [explodeFactor, setExplodeFactor] = useState<number>(0.42);
  const [selectedAssemblyId, setSelectedAssemblyId] =
    useState<AssemblyId>("engine");
  const [selectedPartId, setSelectedPartId] = useState<string>("eng-block");
  const [isolatedAssembly, setIsolatedAssembly] = useState<AssemblyId | null>(
    null
  );
  const [cameraFocusTick, setCameraFocusTick] = useState<number>(0);
  const [studioTargetPart, setStudioTargetPart] =
    useState<ScientificPart | null>(null);

  const handleSelectAssembly = (id: AssemblyId) => {
    setSelectedAssemblyId(id);
    const firstPart = SCIENTIFIC_PARTS.find((p) => p.assemblyId === id);
    if (firstPart) {
      setSelectedPartId(firstPart.id);
    }
  };

  const handleInspectIn3D = (assemblyId: AssemblyId, partId: string) => {
    setSelectedAssemblyId(assemblyId);
    setSelectedPartId(partId);
    setActiveTab("3d");
    setCameraFocusTick((t) => t + 1);
  };

  const handleGenerateImageForPart = (part: ScientificPart) => {
    setStudioTargetPart(part);
    setActiveTab("studio");
  };

  const handlePrimaryExplodeToggle = () => {
    setActiveTab("3d");
    setExplodeFactor((prev) => (prev > 0.5 ? 0 : 1));
  };

  return (
    <div className="relative min-h-screen flex flex-col bg-[#0B0F14] text-slate-100 overflow-x-hidden">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-[#0B0F14]/95 border-b border-white/10 px-3 sm:px-6 h-16 flex items-center justify-between gap-3 sm:gap-8">
        {/* Zone 1: Single-element brand lockup with official logo */}
        <button
          type="button"
          onClick={() => setActiveTab("3d")}
          className="inline-flex items-center gap-2.5 sm:gap-3 font-display text-sm sm:text-lg font-extrabold tracking-tight text-white whitespace-nowrap shrink-0 hover:text-red-400 transition-colors"
        >
          <img
            src="/assets/aistudio/logo_white.png"
            alt="الشعار الرسمي"
            referrerPolicy="no-referrer"
            className="w-9 h-9 sm:w-10 sm:h-10 object-contain shrink-0"
          />
          <span>موسوعة تفكيك L200 · 2016</span>
        </button>

        {/* Zone 2: 4 single-line navigation links */}
        <nav
          aria-label="التنقل الرئيسي"
          className="hidden md:flex items-center gap-6 text-sm font-medium"
        >
          {(
            [
              { id: "3d", label: "التشريح ثلاثي الأبعاد" },
              { id: "breakdown", label: "التفكيك العلمي" },
              { id: "studio", label: "استوديو الصور 4K" },
              { id: "physics", label: "المختبر الفيزيائي" },
            ] as const
          ).map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                  active
                    ? "text-white border-red-600"
                    : "text-slate-400 border-transparent hover:text-slate-100"
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary CTA */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={handlePrimaryExplodeToggle}
            className="px-3 sm:px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
          >
            {explodeFactor > 0.5 ? "إعادة التجميع" : "تفكيك كامل"}
          </button>
        </div>
      </header>

      {/* Mobile Nav Bar (Only shown below md) */}
      <nav
        aria-label="التنقل السريع"
        className="relative z-20 flex md:hidden items-center gap-2 overflow-x-auto px-3 py-2.5 bg-[#111722] border-b border-white/8"
      >
        {(
          [
            { id: "3d", label: "التشريح 3D" },
            { id: "breakdown", label: "التفكيك العلمي" },
            { id: "studio", label: "استوديو 4K" },
            { id: "physics", label: "المختبر الفيزيائي" },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActiveTab(item.id)}
            className={`px-3 py-2 rounded-md text-xs font-medium whitespace-nowrap shrink-0 ${
              activeTab === item.id
                ? "bg-red-600 text-white"
                : "text-slate-300 bg-slate-900/70"
            }`}
          >
            {item.label}
          </button>
        ))}
      </nav>

      {/* Main Content Stage */}
      <main className="relative z-10 flex-1 flex flex-col">
        {activeTab === "3d" && (
          <div className="flex-1 max-w-[1440px] w-full mx-auto p-3 sm:p-5 grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-stretch">
            {/* 3D Interactive Stage (~65% width on desktop) */}
            <div className="lg:col-span-8 h-[56vh] min-h-[380px] sm:min-h-[500px] lg:h-[calc(100vh-6.5rem)]">
              <L200Viewport3D
                explodeFactor={explodeFactor}
                onExplodeChange={setExplodeFactor}
                selectedAssemblyId={selectedAssemblyId}
                onSelectAssembly={handleSelectAssembly}
                isolatedAssembly={isolatedAssembly}
                onToggleIsolate={setIsolatedAssembly}
                cameraFocusTick={cameraFocusTick}
              />
            </div>

            {/* Scientific Engineering Inspector (~35% width on desktop) */}
            <div className="lg:col-span-4 lg:h-[calc(100vh-6.5rem)]">
              <ScientificInspector
                selectedAssemblyId={selectedAssemblyId}
                selectedPartId={selectedPartId}
                onSelectPart={setSelectedPartId}
                onGenerateImageForPart={handleGenerateImageForPart}
              />
            </div>
          </div>
        )}

        {activeTab === "breakdown" && (
          <FullBreakdownView
            onInspectIn3D={handleInspectIn3D}
            onGenerateImageForPart={handleGenerateImageForPart}
          />
        )}

        {activeTab === "studio" && (
          <ImageStudio initialPart={studioTargetPart} />
        )}

        {activeTab === "physics" && <PhysicsSpecsView />}
      </main>
    </div>
  );
}
