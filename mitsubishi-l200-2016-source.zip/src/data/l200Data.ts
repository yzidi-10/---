import heroCutawayImg from "../assets/images/l200_hero_cutaway_1794758344326.jpg";
import engine4n15Img from "../assets/images/l200_engine_4n15_1794758346013.jpg";
import drivetrain4wdImg from "../assets/images/l200_drivetrain_4wd_1794758346867.jpg";
import chassisSuspensionImg from "../assets/images/l200_chassis_suspension_1794758347214.jpg";

export type AssemblyId =
  | "engine"
  | "drivetrain"
  | "chassis"
  | "suspension"
  | "brakes_steering"
  | "cooling"
  | "exhaust_fuel"
  | "body_wheels";

export interface ScientificPart {
  id: string;
  assemblyId: AssemblyId;
  partCode: string;
  nameAr: string;
  nameEn: string;
  material: string;
  operatingSpecs: string;
  scientificPrinciple: string;
  equation: string;
  equationLegend: string;
  mechanicalInteraction: string;
  failureDiagnostics: string;
  imagePrompt: string;
}

export interface VehicleAssembly {
  id: AssemblyId;
  indexLabel: string;
  nameAr: string;
  nameEn: string;
  summaryAr: string;
  massEstimateKg: number;
  accentHex: string;
  heroImage?: string;
  cameraPreset: {
    position: [number, number, number];
    target: [number, number, number];
  };
}

export const GENERATED_GALLERY_IMAGES = {
  heroCutaway: heroCutawayImg,
  engine4n15: engine4n15Img,
  drivetrain4wd: drivetrain4wdImg,
  chassisSuspension: chassisSuspensionImg,
} as const;

export const VEHICLE_OVERVIEW_SPECS = [
  { label: "الطراز والمنصة الهندسية", value: "Mitsubishi L200 (KJ/KK/KL) — الجيل الخامس 2016" },
  { label: "المحرك القياسي الرائد", value: "4N15 2.4L MIVEC Di-D (ألومنيوم بالكامل / VGT)" },
  { label: "القدرة والعزم الأقصى", value: "133 kW (181 PS) @ 3500 rpm · 430 N·m @ 2500 rpm" },
  { label: "نسبة الانضغاط الحرارية", value: "15.5 : 1 (أدنى نسبة في فئة الديزل لتقليل الاهتزاز)" },
  { label: "نظام الدفع الرباعي", value: "Super Select 4WD-II (2H / 4H / 4HLc / 4LLc)" },
  { label: "الشاصي والكتلة الفارغة", value: "إطار سُّلمي فولاذي RISE · الكتلة ~1,910 kg" },
];

export const L200_ASSEMBLIES: VehicleAssembly[] = [
  {
    id: "engine",
    indexLabel: "01",
    nameAr: "محرك 4N15 MIVEC والتوربو",
    nameEn: "2.4L 4N15 Aluminum Turbo-Diesel Engine",
    summaryAr:
      "كتلة ألومنيوم خفيفة الوزن (أخف بـ 30 كجم من 4D56 الحديدي) بنسبة انضغاط 15.5:1 وشاحن توربو متغير الهندسة ونظام حقن مشترك بضغط 2000 بار.",
    massEstimateKg: 198,
    accentHex: "#dc2626",
    heroImage: GENERATED_GALLERY_IMAGES.engine4n15,
    cameraPreset: { position: [2.8, 1.9, 3.2], target: [0, 0.85, 1.35] },
  },
  {
    id: "drivetrain",
    indexLabel: "02",
    nameAr: "ناقل الحركة والدفع الرباعي Super Select 4WD-II",
    nameEn: "6MT/5AT Transmission & Transfer Case",
    summaryAr:
      "منظومة تحويل العزم الطولي مع تفاضل وسطي لزج يسمح بالقيادة على الإسفلت بوضع 4H حتى 100 كم/س وتوزيع عزم 40:60 أمامي/خلفي.",
    massEstimateKg: 164,
    accentHex: "#f59e0b",
    heroImage: GENERATED_GALLERY_IMAGES.drivetrain4wd,
    cameraPreset: { position: [3.2, 1.4, 0.4], target: [0, 0.55, -0.1] },
  },
  {
    id: "chassis",
    indexLabel: "03",
    nameAr: "الشاصي السُّلمي المقاوم للتصادم (RISE)",
    nameEn: "High-Tensile Steel Ladder Frame",
    summaryAr:
      "عمود فقري فولاذي مزدوج العوارض الصندوقية بسمك متدرج يتحمل قوى الالتواء (Torsional Rigidity) وصدمات الطرق الوعرة مع حمولة صافية تفوق 1000 كجم.",
    massEstimateKg: 285,
    accentHex: "#38bdf8",
    heroImage: GENERATED_GALLERY_IMAGES.chassisSuspension,
    cameraPreset: { position: [4.5, 2.3, 3.8], target: [0, 0.4, 0] },
  },
  {
    id: "suspension",
    indexLabel: "04",
    nameAr: "نظام التعليق (مقصات مزدوجة + سست ورقية)",
    nameEn: "Double Wishbone & Rear Leaf Springs",
    summaryAr:
      "تعليق أمامي مستقل بمقصات مزدوجة ونوابض حلزونية للتحكم الهندسي الدقيق بزاوية الكامبر، يقابله محور خلفي صلب بنوابض ورقية نصف إهليلجية.",
    massEstimateKg: 142,
    accentHex: "#10b981",
    heroImage: GENERATED_GALLERY_IMAGES.chassisSuspension,
    cameraPreset: { position: [3.6, 1.1, 2.2], target: [0.85, 0.45, 1.2] },
  },
  {
    id: "brakes_steering",
    indexLabel: "05",
    nameAr: "منظومة المكابح والتوجيه الهيدروليكي",
    nameEn: "Ventilated Discs, Rear Drums & Rack Steering",
    summaryAr:
      "أقراص أمامية مهواة قطر 294 ملم بمكابسين لتبديد الطاقة الحركية حرارياً، وطبول خلفية عالية العزم، مع جريدة وترس توجيه هيدروليكية بنسبة 3.8 لفة.",
    massEstimateKg: 76,
    accentHex: "#ef4444",
    cameraPreset: { position: [2.9, 1.0, 2.4], target: [0.85, 0.45, 1.45] },
  },
  {
    id: "cooling",
    indexLabel: "06",
    nameAr: "التبريد والمبرد البيني (Intercooler) والهواء",
    nameEn: "Dual-Core Radiator & Air-to-Air Intercooler",
    summaryAr:
      "مبادلات حرارية من الألومنيوم الملحوم لخفض حرارة هواء التوربو المضغوط من ~150°C إلى ~45°C، مما يرفع كثافة الأكسجين ويمنع الاشتعال المبكر.",
    massEstimateKg: 28,
    accentHex: "#06b6d4",
    cameraPreset: { position: [2.2, 1.4, 3.6], target: [0, 0.8, 2.1] },
  },
  {
    id: "exhaust_fuel",
    indexLabel: "07",
    nameAr: "العادم (EGR / DPF) وخزان الوقود 75 لتر",
    nameEn: "Exhaust Aftertreatment & 75L Fuel System",
    summaryAr:
      "منظومة معالجة غازات الاحتراق عبر صمام EGR المبرد ومرشح الجسيمات DPF، مع خزان ديزل سفلي محمي من الصدمات.",
    massEstimateKg: 94,
    accentHex: "#a855f7",
    cameraPreset: { position: [-3.4, 1.1, -0.8], target: [0, 0.45, -0.6] },
  },
  {
    id: "body_wheels",
    indexLabel: "08",
    nameAr: "الهيكل الخارجي والمقصورة والصندوق والعجلات",
    nameEn: "RISE Double Cab Body, Cargo Bed & 17\" Wheels",
    summaryAr:
      "مقصورة مزدوجة بهيكل RISE من الفولاذ عالي الشد (بمعامل سحب هوائي Cd=0.40) وصندوق خلفي معزز بأضلاع طولية وعجلات 245/65R17.",
    massEstimateKg: 923,
    accentHex: "#cbd5e1",
    heroImage: GENERATED_GALLERY_IMAGES.heroCutaway,
    cameraPreset: { position: [4.8, 2.2, 4.4], target: [0, 0.9, 0] },
  },
];

export const SCIENTIFIC_PARTS: ScientificPart[] = [
  // 01. ENGINE 4N15
  {
    id: "eng-block",
    assemblyId: "engine",
    partCode: "4N15-BLK-AL",
    nameAr: "كتلة الأسطوانات الألومنيوم (Cylinder Block)",
    nameEn: "Die-Cast Aluminum Cylinder Block (86×105.1 mm)",
    material: "سبيكة ألومنيوم-سيليكون مصبوبة بالضغط (AlSi9Cu3) مع بطانات حديد زهر",
    operatingSpecs: "السعة: 2,442 سم³ · القطر × الشوط: 86 × 105.1 ملم · الحرارة التشغيلية: 92°C",
    scientificPrinciple:
      "تستبدل كتلة 4N15 الحديد الزهر التقليدي بسبائك الألومنيوم ذات الموصلية الحرارية العالية (~150 W/m·K مقارنة بـ 50 للحديد)، مما يسرّع التبديد الحراري ويخفض الكتلة الأمامية بـ 30 كجم، بينما تسمح نسبة الانضغاط المنخفضة (15.5:1) بتقليل إجهادات الذروة على جدران الأسطوانات وخفض الضجيج الاحتراقي.",
    equation: "V_d = (π / 4) · B² · S · N_c  ⇒  (π/4)(8.6)²(10.51)(4) = 2,442 cm³",
    equationLegend: "B: قطر الأسطوانة، S: طول الشوط (طويل الشوط لعزم دوران مرتفع)، Nc: عدد الأسطوانات",
    mechanicalInteraction:
      "تثبت الكتلة على عوارض الشاصي الأمامية عبر وسادتين هيدرو-مطاطيتين، وتحتضن في أسفلها كراسي عمود المرفق الـ 5 وفي أعلاها رأس الأسطوانات بمسامير شد خاضعة للخضوع (TTY).",
    failureDiagnostics:
      "ارتفاع حرارة موضعي نتيجة انسداد قنوات التبريد أو تمدد غير متكافئ عند تلف جوان الرأس؛ يُفحص باختبار ضغط دائرة التبريد وتسرب الغازات (CO2 Block Test).",
    imagePrompt:
      "Technical cutaway CAD rendering of Mitsubishi 4N15 2.4L inline-4 aluminum diesel cylinder block showing cast iron liners, coolant water jackets, and five main bearing saddles, studio rim lighting on dark slate background.",
  },
  {
    id: "eng-mivec",
    assemblyId: "engine",
    partCode: "4N15-MIVEC-OHC",
    nameAr: "رأس الأسطوانات ونظام MIVEC لتوقيت الصمامات",
    nameEn: "DOHC 16V Head & MIVEC Variable Valve Timing",
    material: "رأس ألومنيوم مع أعمدة حدبات فولاذية مقساة بالحث (Induction-Hardened)",
    operatingSpecs: "16 صماماً · عمودا حدبات DOHC · تغير طور السحب حتى 40° كرنك",
    scientificPrinciple:
      "تطبيق نظام التحكم الإلكتروني المتغير في توقيت ورفع الصمامات (MIVEC) على محرك ديزل يرفع الكفاءة الحجمية (Volumetric Efficiency) عند الدورات المنخفضة بتبكير إغلاق صمام السحب لزيادة ضغط الانضغاط الفعلي، وتأخيره عند السرعات العالية لاستغلال القصور الذاتي لعمود الهواء الداخل.",
    equation: "η_v = m_air / (ρ_manifold · V_d)",
    equationLegend: "ηv: الكفاءة الحجمية، m_air: كتلة الهواء المحتجز داخل الأسطوانة، ρ: كثافة هواء المجمع",
    mechanicalInteraction:
      "يدور عمودا الحدبات عبر جنزير توقيت معدني مزدوج موصول بعمود المرفق، ويُتحكم بزاوية الطور عبر مشغل هيدروليكي يعمل بضغط زيت المحرك بأمر من كمبيوتر ECU.",
    failureDiagnostics:
      "تآكل أو تراكم الكربون في صمام التحكم بالزيت (OCV) يؤدي لبطء استجابة السحب وإضاءة لمبة فحص المحرك بكود P0011/P0016.",
    imagePrompt:
      "Scientific exploded CAD diagram of a DOHC 16-valve diesel cylinder head with MIVEC hydraulic cam phaser gear and timing chain, brushed aluminum and hardened steel, dark studio background.",
  },
  {
    id: "eng-vgt",
    assemblyId: "engine",
    partCode: "4N15-VGT-TRB",
    nameAr: "شاحن التوربو متغير الهندسة (VGT)",
    nameEn: "Variable Geometry Turbocharger",
    material: "غلاف توربيني من فولاذ مقاوم للحرارة (Ni-Resist) وريش من سبيكة Inconel 713C",
    operatingSpecs: "ضغط شحن حتى 1.65 bar (نسبي) · سرعة دوران: 180,000 RPM · حرارة العادم حتى 820°C",
    scientificPrinciple:
      "يستعيد الشاحن الطاقة الإنتالبية الضائعة في غازات العادم. عبر تغيير زاوية الريش التوجيهية (Guide Vanes) حول عجلة التوربين، تتقلص مساحة الفوهة عند الدورات المنخفضة فتتسارع الغازات وفق معادلة الاستمرارية وبرنولي لتدوير التوربين فوراً (إزالة تأخر التوربو Turbo Lag)، ثم تتفتح عند الدورات العالية لمنع فرط الضغط.",
    equation: "A₁·v₁ = A₂·v₂  &  T₂ = T₁ · (P₂/P₁)^((γ-1)/γ) / η_c",
    equationLegend: "تضييق المقطع A يرفع سرعة الغاز v؛ والانضغاط الأديباتيكي يرفع حرارة الهواء T2 مما يستلزم مبرداً بينياً",
    mechanicalInteraction:
      "يركب مباشرة على مشعب العادم ويُغذى بزيت المحرك المضغوط للتزييت والتبريد الهيدروديناميكي لمحامل العمود، ويتصل بمشغل كهربائي أو تفريغي مرتبط بحساس ضغط MAP.",
    failureDiagnostics:
      "تجمّد الريش المتغيرة بسبب السخام الكربوني يسبب زيادة مفرطة في البوست (Overboost P0234) أو ضعف العزم (Underboost P0299).",
    imagePrompt:
      "Cross-section technical illustration of a variable geometry turbocharger (VGT) showing movable actuator nozzle vanes, Inconel turbine wheel, and aluminum compressor housing, dark studio engineering aesthetic.",
  },
  {
    id: "eng-commonrail",
    assemblyId: "engine",
    partCode: "4N15-CRDI-2K",
    nameAr: "منظومة الحقن المشترك (Common Rail 2000 bar)",
    nameEn: "High-Pressure Common Rail & Piezo/Solenoid Injectors",
    material: "فولاذ سبائكي مطروق عالي المتانة (AISI 4140) وفوهات مثقوبة بالليزر",
    operatingSpecs: "ضغط السكة: 300–2,000 bar · حتى 5 حقنات في الشوط الواحد (Pilot + Main + Post)",
    scientificPrinciple:
      "تُضخ السولار بمضخة مكبسية عالية الضغط إلى أنبوب مشترك يعمل كمركم هيدروليكي (Hydraulic Accumulator) لعزل تغيرات الضغط عن سرعة المحرك. عند ضغط 2000 بار تتفتت قطيرات الديزل بقطر أقل من 15 ميكرومتر (Atomization) وفق رقم ويبر (Weber Number)، مما يضمن اختلاطاً فائق السرعة مع الأكسجين واحتراقاً أنظف.",
    equation: "Q = C_d · A · √(2·ΔP / ρ_fuel)  |  We = (ρ_air · v² · d) / σ",
    equationLegend: "ΔP: فرق الضغط عبر فوهة البخاخ، d: قطر القطيرة، σ: التوتر السطحي للوقود",
    mechanicalInteraction:
      "تسحب مضخة الإمداد الوقود عبر فلتر 2-ميكرون وتضغطه إلى مسطرة التوزيع المزودة بحساس ضغط وصمام تصريف SCV، وتفتح البخاخات بنبضات من ECU.",
    failureDiagnostics:
      "تلف صمام التحكم بالشفط (SCV) يسبب تذبذب الـ RPM عند التوقف، بينما تآكل فوهات البخاخ يظهر دخاناً أسود وطرقاً معدنياً.",
    imagePrompt:
      "Precision technical cutaway of a 2000-bar diesel common rail fuel injection system with forged high-pressure rail, multi-plunger supply pump, and laser-drilled multi-hole injectors, dark background.",
  },
  {
    id: "eng-pistons-crank",
    assemblyId: "engine",
    partCode: "4N15-RECIP-05",
    nameAr: "المكابس والأذرع وعمود المرفق",
    nameEn: "Pistons, Forged Connecting Rods & Crankshaft",
    material: "مكابس ألومنيوم بطبقة جرافيت مضادة للاحتكاك · أذرع وكرنك من فولاذ مطروق 42CrMo4",
    operatingSpecs: "نسبة ضغط احتراق ذروي: 165 bar · 8 أوزان موازنة · حلقة تبريد زيتية داخلية",
    scientificPrinciple:
      "تحول آلية الكرنك-الذراع الحركة الترددية الخطية الناتجة عن تمدد غازات الاحتراق ($F = P \cdot A$) إلى عزم دوران دوراني ($\tau = F \cdot r \cdot \sin\theta$). وبسبب انخفاض الانضغاط إلى 15.5:1، جرى تخفيف كتلة المكابس بنسبة 15% لتقليل قوى القصور الذاتي الترددية ($F_i = m \omega^2 r$) والاهتزازات.",
    equation: "τ(θ) = P(θ) · A_piston · r · [sin(θ) + (r / 2L)·sin(2θ)]",
    equationLegend: "r: نصف قطر الكرنك، L: طول ذراع التوصيل، θ: زاوية دوران المرفق",
    mechanicalInteraction:
      "يحتوي رأس المكبس على تجويف احتراق حلقي (Omega Bowl) لتوليد دوامة هوائية (Swirl)، ويرتبط بعمود المرفق الذي يدير حدافة الكتلة المزدوجة (DMF) لنقل العزم للقير.",
    failureDiagnostics:
      "فحص ضغط الأسطوانات (Compression Test ~26–30 bar) يكشف تآكل شنابر الضغط، بينما سماع طرق معدني متسارع يشير لتآكل سبائك الذراع.",
    imagePrompt:
      "Isometric engineering illustration of diesel engine forged steel crankshaft, I-beam connecting rods, and aluminum pistons with omega combustion bowl and oil cooling gallery, dark studio background.",
  },

  // 02. DRIVETRAIN
  {
    id: "drv-gearbox",
    assemblyId: "drivetrain",
    partCode: "V6M5A-MT6-AT5",
    nameAr: "ناقل الحركة (يدوي 6 سرعات / أوتوماتيكي 5 سرعات)",
    nameEn: "6-Speed Manual & 5-Speed INVECS-II Automatic",
    material: "علبة ألومنيوم مضلعة لتبديد الحرارة · تروس حلزونية من فولاذ مكربن (20MnCr5)",
    operatingSpecs: "نسبة الترس الأول: 4.313 (MT) · السادس: 0.788 · سعة الزيت: 2.5–9.7 لتر",
    scientificPrinciple:
      "يضرب صندوق التروس عزم المحرك في نسبة الترس المحدد لموازنة قوة الجر عند الإقلاع مقابل السرعة القصوى. التروس الحلزونية (Helical Gears) تتعاشق تدريجياً على طول السن، مما يقلل الضجيج الصدمي مقارنة بالتروس المستقيمة، مع وجود حلقات تزامن (Synchronizers) لمساواة السرعة الزاوية بالاحتكاك المخروطي قبل التعشيق.",
    equation: "τ_out = τ_engine · i_gear · η_mesh  |  ω_out = ω_engine / i_gear",
    equationLegend: "i_gear: نسبة التخفيض للترس، η_mesh ≈ 0.97 لكل مرحلة تعشيق تروس",
    mechanicalInteraction:
      "يستلم الحركة من المحرك عبر قابض احتكاكي جاف (في اليدوي) أو محول عزم هيدروليكي بقفل Lock-up Clutch (في الأوتوماتيكي)، ويسلمها مباشرة لمدخل علبة التحويل.",
    failureDiagnostics:
      "خشونة التعشيق أو ارتداد عصا القير تدل على تآكل النحاسات (Synchro Rings) أو انخفاض لزوجة زيت GL-4 / ATF SP-III.",
    imagePrompt:
      "Exploded 3D engineering rendering of a heavy-duty 6-speed automotive manual gearbox showing helical gearsets, brass synchronizer rings, input/output shafts, and ribbed aluminum casing.",
  },
  {
    id: "drv-transfercase",
    assemblyId: "drivetrain",
    partCode: "SS4II-TC-VCU",
    nameAr: "علبة التحويل ونظام Super Select 4WD-II",
    nameEn: "Super Select 4WD-II Transfer Case with Viscous Center Diff",
    material: "غلاف ألومنيوم مقوى · جنزير نقل صامت (Morse Chain) · تروس كوكبية",
    operatingSpecs: "الأوضاع: 2H / 4H (40:60) / 4HLc (50:50) / 4LLc (تخفيض 2.566:1)",
    scientificPrinciple:
      "يمتاز L200 بوجود تفاضل وسطي تروس مخروطية مع قابض لزج (Viscous Coupling Unit) مملوء بسائل السيليكون غير النيوتوني؛ عند انزلاق أي محور ترتفع حرارة القص في السائل وتزداد لزوجته فتتوزع القوة ديناميكياً، مع إمكانية قفله ميكانيكياً (4HLc) وتفعيل مجموعة التروس الكوكبية المضاعفة للعزم في 4LLc.",
    equation: "τ_4LLc = τ_gearbox · 2.566  ⇒  عزم إجمالي هائل عند العجلات",
    equationLegend: "تقوم المجموعة الكوكبية بمضاعفة العزم بمقدار 2.566 ضعف مع تقسيم 50:50 بين الأمام والخلف",
    mechanicalInteraction:
      "تتصل بمخرج القير وتفرّع العزم إلى عمود دوران خلفي وعمود أمامي يغذي الدفرنس الأمامي، وتتحكم بها مشغلات كهربائية ومفاتيح فراغ/حساسات موقع.",
    failureDiagnostics:
      "وميض لمبة الدبل البرتقالية في الطبلون ينتج غالباً عن تلف حساسات موقع التحويل الخمسة أو تأكسد فيش المشغل الكهربائي.",
    imagePrompt:
      "Technical cutaway illustration of Mitsubishi Super Select 4WD-II transfer case showing planetary low-range gearset, silent drive chain, and viscous coupling center differential on dark slate.",
  },
  {
    id: "drv-propshafts",
    assemblyId: "drivetrain",
    partCode: "SS4II-PROP-UJ",
    nameAr: "أعمدة الدوران والمفاصل الكردانية (الصلبان)",
    nameEn: "Tubular Steel Propeller Shafts & Cardan U-Joints",
    material: "أنابيب فولاذية مسحوبة على البارد وموزونة ديناميكياً · محامل إبرية",
    operatingSpecs: "السرعة الحرجة > 5,000 RPM · تحمل إجهاد التواء > 2,200 N·m",
    scientificPrinciple:
      "تُصمّم أعمدة الدوران كأنابيب مجوفة لأن الإجهاد الأقصى في الالتواء يتركز على السطح الخارجي ($τ = T·r / J$)، مما يحقق أعلى صلابة بأقل كتلة دوارة وعزم قصور ذاتي. وتُركّب الوصلات الكردانية (U-Joints) بزوايا متناظرة لإلغاء التذبذب غير المتساوي في السرعة الزاوية (Non-uniform Angular Velocity).",
    equation: "τ_max = (T · r_outer) / J  ,  J = (π / 2)·(r_outer⁴ - r_inner⁴)",
    equationLegend: "J: عزم القصور الذاتي القطبي للمقطع الأنبوبي، T: عزم الالتواء المنقول",
    mechanicalInteraction:
      "تربط علبة التحويل بالدفرنس الخلفي عبر شيّال وسطي بمطاط ماص للاهتزازات (Center Bearing) ووصلة انزلاقية (Slip Yoke) لامتصاص تغير الطول عند حركة التعليق.",
    failureDiagnostics:
      "رجة دورية عند سرعة 60–90 كم/س أو صوت طقة عند التبديل من R إلى D تشير لتلف الصليبات أو جفاف مطاط الشيّال الوسطي.",
    imagePrompt:
      "Engineering rendering of an automotive two-piece steel propeller shaft with Cardan universal joints, spline slip yoke, and rubber-isolated center support bearing.",
  },
  {
    id: "drv-reardiff",
    assemblyId: "drivetrain",
    partCode: "AXL-RR-RDLCK",
    nameAr: "الدفرنس الخلفي وقفل الدفرنس (Rear Diff Lock)",
    nameEn: "Hypoid Rear Axle & Mechanical Differential Lock",
    material: "غلاف فولاذي مضغوط (Banjo Axle) · ترس التاج والبنيون من فولاذ 8620 مكربن",
    operatingSpecs: "النسبة النهائية: 3.692 / 3.917 / 4.090 · زيت GL-5 80W-90",
    scientificPrinciple:
      "يستخدم ترس التاج والبنيون تصميماً هيبويدياً (Hypoid Bevel Gears) حيث ينزاح محور البنيون أسفل مركز التاج لزيادة مساحة تلامس الأسنان وخفض ارتفاع أرضية المقصورة. يسمح التفاضل المفتوح باختلاف سرعة العجلتين في المنعطفات ($ω_L + ω_R = 2ω_carrier$)، وعند تفعيل القفل الخلفي تتعشق جلبة مسننة تجبر العجلتين على الدوران بسرعة متطابقة 100%.",
    equation: "ω_left + ω_right = 2 · ω_crown  |  (عند تفعيل القفل: ω_left = ω_right)",
    equationLegend: "عند غرز إحدى العجلتين في الرمل يفرغ التفاضل المفتوح العزم نحوها؛ القفل يعيد 50% للعجلة الثابتة",
    mechanicalInteraction:
      "يحمل وزن المحور الخلفي، ويرتكز على السست الورقية، ويمرر الحركة عبر عكسين (Axle Shafts) شبه عائمين إلى صرة العجلات الخلفية.",
    failureDiagnostics:
      "صوت حنّة/صفير يزداد مع التسارع ويزول عند رفع القدم يدل على خلل خلوص البنيون أو تآكل رمانات الدفرنس.",
    imagePrompt:
      "Exploded mechanical CAD illustration of a truck hypoid rear differential housing, ring and pinion bevel gears, spider gears, and electromagnetic/pneumatic diff-lock collar.",
  },

  // 03. CHASSIS
  {
    id: "chs-rails",
    assemblyId: "chassis",
    partCode: "RISE-FRM-HT590",
    nameAr: "العوارض الطولية الصندوقية (Boxed Ladder Rails)",
    nameEn: "High-Tensile Steel Boxed Chassis Side Rails",
    material: "فولاذ عالي الشد (HTSS 440–590 MPa) ملحوم بالليزر بتقنية RISE",
    operatingSpecs: "مقطع صندوقي مغلق 150×65 ملم · الحمولة الصافية: 1,045 كجم · السحب: 3,100 كجم",
    scientificPrinciple:
      "يعتمد الشاصي السُّلمي على فصل إجهادات الحمولة والالتواء عن جسم المقصورة. المقطع المستطيل المغلق (Closed Box Section) يضاعف مقاومة الالتواء (Torsional Stiffness) بأكثر من 10 مرات مقارنة بالمقطع المفتوح C-Channel، مع استخدام طيّات تشوّه مبرمجة في المقدمة لامتصاص الطاقة الحركية للتصادم ($\frac{1}{2}mv^2$).",
    equation: "σ_bending = (M · y) / I_x  |  θ_twist = (T · L) / (G · J)",
    equationLegend: "M: عزم الانحناء من الحمولة، Ix: عزم القصور الذاتي للمقطع، G: معامل القص للفولاذ",
    mechanicalInteraction:
      "يشكّل الأساس الهيكلي الذي تُثبّت عليه قواعد المحرك، التعليق الأمامي والخلفي، خزان الوقود، والمقصورة عبر 8 وسائد مطاطية عازلة للاهتزازات.",
    failureDiagnostics:
      "الالتواء الناتج عن الحوادث أو الصدأ في نقاط لحام الحوامل الخلفية يؤدي لانحراف هندسة العجلات (Wheel Alignment) وتآكل غير منتظم للإطارات.",
    imagePrompt:
      "Technical CAD illustration of a pickup truck high-tensile steel boxed ladder-frame chassis showing front crash zones, crossmembers, and hydroformed side rails.",
  },
  {
    id: "chs-crossmembers",
    assemblyId: "chassis",
    partCode: "RISE-XMEM-06",
    nameAr: "العوارض العرضية وقواعد التثبيت (Crossmembers)",
    nameEn: "Stamped & Tubular Crossmembers & Engine Mounts",
    material: "فولاذ هيكلي SPFH540 + مطاط طبيعي عازل للترددات المنخفضة",
    operatingSpecs: "6 عوارض عرضية رئيسية · عزل اهتزازات < 30 Hz",
    scientificPrinciple:
      "تمنع العوارض العرضية انفتاح أو تقارب العارضتين الطوليتين (Racking/Lozenge Deformation) عند صعود العوائق المائلة. وتعمل العارضة الوسطى كحامل لناقل الحركة مع وجود صفيحة حماية سفلية (Skid Plate) لتشتيت صدمات الصخور.",
    equation: "k_eq = 1 / (1/k_frame + 1/k_mount)  |  f_n = (1/2π)√(k/m)",
    equationLegend: "اختيار جساءة المطاط يبعد التردد الطبيعي للمحرك fn عن تردد اهتزاز التباطؤ (Idle ~25 Hz)",
    mechanicalInteraction:
      "تربط الجانبين الأيمن والأيسر للشاصي وتشكل نقاط ارتكاز مقصورة القيادة، الرديتر، القير، والصندوق الخلفي.",
    failureDiagnostics:
      "تمزق كراسي المحرك أو القير ينقل رجة الديزل مباشرة إلى مقود القيادة وأرضية المقصورة.",
    imagePrompt:
      "Close-up CAD diagram of heavy-duty pickup truck tubular and stamped steel chassis crossmembers with rubber body mounts and transmission support bracket.",
  },

  // 04. SUSPENSION
  {
    id: "sus-wishbone",
    assemblyId: "suspension",
    partCode: "SUS-FR-DWB",
    nameAr: "نظام التعليق الأمامي بالمقصات المزدوجة",
    nameEn: "Front Independent Double Wishbone & Coilover",
    material: "أذرع فولاذية مطروقة ومختومة · جلب مطاطية متحدة المركز · نوابض سيليكون-كروم",
    operatingSpecs: "شوط التعليق: ~190 ملم · صلبوية النابض: ~85 N/mm",
    scientificPrinciple:
      "يتكون من ذراع علوي أقصر وذراع سفلي أطول (SLA - Short-Long Arm). عند انضغاط العجلة لأعلى، تتسبب هذه الهندسة في زيادة زاوية الكامبر السالبة (Negative Camber Gain) تلقائياً لتعويض ميلان جسم السيارة في المنعطفات، مما يحافظ على أكبر مساحة تلامس للإطار مع الطريق.",
    equation: "F_spring = -k · Δx  |  F_damper = -c · (dx/dt)",
    equationLegend: "قانون هوك للنابض الحلزوني مقترناً بالتخميد اللزج لممتص الصدمات الغازي-الهيدروليكي",
    mechanicalInteraction:
      "يتصل المقصان بالفلنجة (Steering Knuckle) عبر ركب علوية وسفلية (Ball Joints)، ويمر بينهما عمود العكس الأمامي في طرازات 4WD.",
    failureDiagnostics:
      "خلوص الركب (Ball Joints) أو تآكل جلد المقصات يسبب طقطقة عند المطبات وتغييراً مستمراً في زوايا التوازي (Toe/Camber).",
    imagePrompt:
      "Technical isometric cutaway of a truck front independent double wishbone suspension showing upper and lower A-arms, helical coil spring over twin-tube shock absorber, ball joints, and sway bar.",
  },
  {
    id: "sus-leafspring",
    assemblyId: "suspension",
    partCode: "SUS-RR-LEAF",
    nameAr: "السست الورقية الخلفية (Semi-Elliptic Leaf Springs)",
    nameEn: "Heavy-Duty Multi-Leaf Springs & Twin-Tube Dampers",
    material: "فولاذ نوابض SUP9 مقسى ومقذوف بالكريات (Shot-Peened)",
    operatingSpecs: "5–6 ريش فولاذية بطول 1,300 ملم · مثبتة فوق/تحت المحور بمسامير U-Bolt",
    scientificPrinciple:
      "تعمل السست الورقية كجسر مرن موزع للإجهاد (Cantilever Beam of Uniform Strength)؛ تتحمل في آن واحد الأحمال العمودية الهائلة وتحدد موضع المحور الخلفي طولياً وجانبياً دون الحاجة لأذرع ربط إضافية. الاحتكاك البيني بين الريش يوفر تخميداً ذاتياً إضافياً عند الحمولات الثقيلة.",
    equation: "σ_max = (3 · F · L) / (2 · n · b · t²)  |  δ = (F · L³) / (4 · E · n · b · t³)",
    equationLegend: "n: عدد الريش، b: عرض الريشة، t: سماكة الريشة، L: نصف طول النابض، E: معامل يونغ",
    mechanicalInteraction:
      "تثبت من الأمام ببن ثابت في الشاصي ومن الخلف بأرجوحة (Shackle) تسمح بتمدد طول السستة عند الانضغاط، ويميل مصاص الصدمات بزاوية مائلة لتثبيت اهتزاز المحور.",
    failureDiagnostics:
      "انكسار إحدى الريش أو جفاف جلب الشاكل يسبب ميلاً في ارتفاع الخلفية وصرير احتكاك معدني مستمر.",
    imagePrompt:
      "CAD engineering rendering of heavy-duty pickup truck semi-elliptic multi-leaf spring assembly with U-bolts, rear shackle, rubber bump stop, and angled hydraulic shock absorber.",
  },

  // 05. BRAKES & STEERING
  {
    id: "brk-discs",
    assemblyId: "brakes_steering",
    partCode: "BRK-FR-294V",
    nameAr: "الأقراص الأمامية المهواة وكليبرات المكابح",
    nameEn: "294mm Ventilated Brake Discs & Twin-Piston Calipers",
    material: "حديد زهر رمادي عالي الكربون (G3000) · فحمات شبه معدنية/سيراميك",
    operatingSpecs: "القطر: 294 ملم · السماكة: 24 ملم · التبديد الحراري > 450°C",
    scientificPrinciple:
      "تتحول الطاقة الحركية للسيارة بالكامل ($\frac{1}{2}mv^2$) إلى طاقة حرارية عبر الاحتكاك الجاف بين الفحمات والقرص بضغط هيدروليكي متضاعف وفق مبدأ باسكال ($P = F/A$). القناة الوسطية بين وجهي القرص تحتوي على زعانف شعاعية تعمل كمضخة طرد مركزي تسحب الهواء البارد لطرد الحرارة ومنع غليان سائل الفرامل (Brake Fade).",
    equation: "E_k = ½ m v² = Q_heat = m_disc · c_p · ΔT  |  τ_brake = 2 · μ · F_clamp · r_eff",
    equationLegend: "μ: معامل الاحتكاك (~0.38)، F_clamp: قوة المكبسين الهيدروليكيين، r_eff: نصف القطر الفعال",
    mechanicalInteraction:
      "يدور القرص مع صرة العجلة ذات الـ 6 مسامير، بينما يثبت الكليبر على الفلنجة ويتصل بخراطيم هيدروليكية مرنة قادمة من وحدة ABS/EBD.",
    failureDiagnostics:
      "التواء القرص نتيجة التبريد المفاجئ بالماء يسبب نبضاً واضحاً في دواسة الفرامل وعجلة القيادة عند الكبح من سرعة عالية.",
    imagePrompt:
      "Cross-section technical CAD model of a 294mm ventilated automotive brake rotor with radial cooling vanes and dual-piston floating brake caliper.",
  },
  {
    id: "brk-drums-abs",
    assemblyId: "brakes_steering",
    partCode: "BRK-RR-DRM-ABS",
    nameAr: "مكابح الطبول الخلفية ووحدة ABS/EBD",
    nameEn: "295mm Rear Drum Brakes & Hydraulic ABS Modulator",
    material: "طبل من حديد زهر مقسى · صمامات كهرومغناطيسية عالية التردد (15 Hz)",
    operatingSpecs: "قطر الطبل: 295 ملم · توزيع إلكتروني EBD + مساعد كبح BA",
    scientificPrinciple:
      "تستفيد المكابح الطبلية من ظاهرة التفعيل الذاتي (Self-Energizing Effect) حيث يسحب دوران الطبل حذاء الكبح الأساسي (Leading Shoe) بقوة أكبر نحو السطح الداخلي، مما يوفر قوة تثبيت عالية للفرامل اليدوية والحمولات الخلفية، بينما يراقب نظام ABS/EBD سرعة دوران كل عجلة لمنع انغلاقها والاحتفاظ بالاحتكاك الستاتيكي الأقصى ($μ_s > μ_k$).",
    equation: "λ_slip = (v_vehicle - ω·r_wheel) / v_vehicle  (النطاق المثالي للكبح: 10%–20%)",
    equationLegend: "λ: نسبة الانزلاق؛ يحافظ منظم ABS على الانزلاق في نطاق الذروة لمنع فقدان التوجيه",
    mechanicalInteraction:
      "تتلقى وحدة ABS إشارات حساسات Hall-Effect من العجلات الأربع وتعدل الضغط الهيدروليكي المرسل لكل عجلة على حدة.",
    failureDiagnostics:
      "إضاءة لمبة ABS مع فقدان عداد السرعة غالباً ما تنتج عن اتساخ أو قطع سلك حساس العجلة الخلفية في الطرق الوعرة.",
    imagePrompt:
      "Exploded technical diagram of a truck rear drum brake assembly showing leading/trailing brake shoes, wheel cylinder, return springs, and electronic ABS hydraulic modulator block.",
  },
  {
    id: "str-rack",
    assemblyId: "brakes_steering",
    partCode: "STR-HYD-RACK",
    nameAr: "دودة التوجيه الهيدروليكية (Rack & Pinion)",
    nameEn: "Hydraulic Power-Assisted Rack & Pinion Steering",
    material: "ترس وجريدة مسننة من فولاذ مقسى · غلاف من سبيكة ألومنيوم",
    operatingSpecs: "دورات المقود: 3.8 لفة · ضغط مضخة الباور: 90–105 bar · قطر الدوران: 11.8 م",
    scientificPrinciple:
      "تحول الحركة الدورانية لعمود المقود إلى إزاحة خطية تدفع ذراعي التوجيه (Tie Rods) بزاوية أكرمان (Ackermann Geometry) بحيث تدور العجلة الداخلية بزاوية أكبر من الخارجية لمنع زحف الإطارات. يساعد صمام الدوران (Rotary Valve) في توجيه زيت الباور عالي الضغط إلى أحد جانبي المكبس داخل الدودة لتخفيف جهد السائق.",
    equation: "cot(δ_outer) - cot(δ_inner) = W / L_wheelbase",
    equationLegend: "هندسة أكرمان: W عرض المسار، L قاعدة العجلات (3000 ملم في L200) لتتقاطع محاور الدوران في نقطة واحدة",
    mechanicalInteraction:
      "ترتبط بعارضة الشاصي الأمامية، وتتصل بفلنجات العجلات الأمامية عبر أذرع داخلية وخارجية وبمضخة هيدروليكية يديرها سير المحرك.",
    failureDiagnostics:
      "تهريب زيت الباور من صوف الدودة أو سماع أزيز في المضخة عند أقصى التفاف يشير لانخفاض السائل أو تآكل ريش المضخة.",
    imagePrompt:
      "Cutaway engineering rendering of an automotive hydraulic power-assisted rack and pinion steering gear showing rotary spool valve, hydraulic piston seal, and inner/outer tie rods.",
  },

  // 06. COOLING
  {
    id: "clg-radiator",
    assemblyId: "cooling",
    partCode: "CLG-RAD-AL2",
    nameAr: "الرديتر الألومنيوم ومروحة الكلتش اللزج",
    nameEn: "Dual-Row Aluminum Radiator & Viscous Clutch Fan",
    material: "أنابيب وزعانف ألومنيوم ملحومة بالنحاس/الألومنيوم + خزانات بوليمر PA66-GF30",
    operatingSpecs: "فتح الثرموستات: 82°C · ضغط الغطاء: 1.1 bar (يرفع درجة الغليان إلى ~124°C)",
    scientificPrinciple:
      "ينقل سائل التبريد (50% ماء + 50% جليكول الإيثيلين) الحرارة من جدران الأسطوانات بالحمل الحراري القسري عبر مضخة الطرد المركزي إلى شبكة الزعانف المموجة ذات المساحة السطحية الضخمة. تتحكم المروحة ذات الكلتش اللزج بالسيليكون في تدفق الهواء نسبياً مع حرارة الهواء المار عليها دون استهلاك قدرة ثابتة من المحرك.",
    equation: "Q̇ = ṁ · c_p · ΔT = U · A_surface · ΔT_lm",
    equationLegend: "ṁ: معدل تدفق سائل التبريد، U: معامل انتقال الحرارة الكلي، ΔT_lm: فرق الحرارة اللوغاريتمي المتوسط",
    mechanicalInteraction:
      "يوضع خلف الشبك الأمامي مباشرة، ويتصل بالمحرك عبر خرطوم علوي (ساخن) وسفلي (مبرد) وبقربة التمدد البلاستيكية.",
    failureDiagnostics:
      "تلف الكلتش اللزج يجعل المروحة تدور ببطء عند التوقف في الصيف فترتفع الحرارة، بينما يعود التبريد فور التسارع على الطريق السريع.",
    imagePrompt:
      "Technical illustration of a dual-row aluminum automotive radiator with corrugated cooling fins, side tanks, thermostat housing, and silicon-fluid viscous clutch cooling fan.",
  },
  {
    id: "clg-intercooler",
    assemblyId: "cooling",
    partCode: "CLG-IC-FMIC",
    nameAr: "المبرد البيني لهواء التوربو (Intercooler)",
    nameEn: "Front-Mounted Air-to-Air Charge Air Cooler",
    material: "ألومنيوم مبثوق (Bar-and-Plate Core) + خراطيم سيليكون مقواة بأربع طبقات",
    operatingSpecs: "خفض حرارة الهواء: من ~155°C إلى ~48°C · هبوط الضغط < 0.08 bar",
    scientificPrinciple:
      "انضغاط الهواء في التوربو يرفع حرارته أديباتيكياً مما يخفض كثافته. يقوم المبرد البيني بتبريد الهواء المضغوط قبل دخوله المحرك، ووفق قانون الغاز المثالي ($ρ = P / R·T$) يؤدي خفض الحرارة المطلقة T بنسبة 25% إلى زيادة كثافة الأكسجين بنحو 30% في نفس الحجم، ما يرفع القدرة ويمنع ارتفاع حرارة العادم.",
    equation: "ρ_air = P_boost / (R_specific · T_abs)  ⇒  ↓T  ⟹  ↑ρ  ⟹  ↑Power",
    equationLegend: "خفض T بالكلفن يرفع الكتلة النوعية للهواء الداخل إلى غرفة الاحتراق دون زيادة حجم الأسطوانة",
    mechanicalInteraction:
      "يموضع في مقدمة الصدام الأمامي أسفل الرديتر، ويتصل بمخرج ضاغط التوربو وبمجمع السحب عبر أنابيب معدنية ومشابك عالية الشد.",
    failureDiagnostics:
      "انشقاق أحد خراطيم التوربو أو ثقب في المبرد يظهر صفير هواء حاد عند التسارع ودخان أسود بسبب نقص الهواء مقابل الوقود المحقون.",
    imagePrompt:
      "CAD engineering rendering of a front-mounted aluminum bar-and-plate air-to-air intercooler with cast aluminum end tanks and reinforced silicone boost hoses.",
  },

  // 07. EXHAUST & FUEL
  {
    id: "exh-egr-dpf",
    assemblyId: "exhaust_fuel",
    partCode: "EXH-EGR-DPF",
    nameAr: "صمام EGR المبرد ومرشح الجسيمات (DPF)",
    nameEn: "Water-Cooled EGR Valve & Diesel Particulate Filter",
    material: "مبادل EGR من الستانلس ستيل · قلب DPF من كربيد السيليكون (SiC) المسامي",
    operatingSpecs: "التجديد الحراري (Regeneration): 600°C · احتجاز >95% من السخام",
    scientificPrinciple:
      "تتكون أكاسيد النيتروجين ($NO_x$) عند تجاوز حرارة الاحتراق 1800K؛ يعيد صمام EGR المبرد كمية محسوبة من غاز العادم الخامل لرفع السعة الحرارية للخليط وخفض ذروة الحرارة. أما مرشح DPF فيصطاد جسيمات الكربون الدقيقة في قنوات خلوية متبادلة الإغلاق، ثم يحرقها دورياً بتحويلها إلى $CO_2$ بحقنة ديزل لاحقة (Post-injection).",
    equation: "C (Soot) + O₂  —(600°C / Catalyst)→  CO₂   |   ↓T_peak  ⟹  ↓↓NO_x",
    equationLegend: "توازن كيميائي-حراري بين خفض أكاسيد النيتروجين عبر EGR وأكسدة الكربون داخل مرشح DPF",
    mechanicalInteraction:
      "يربط صمام EGR بين مشعب العادم ومجمع السحب، بينما يقع مرشح DPF أسفل المقصورة مزوداً بحساس فرق ضغط (Differential Pressure Sensor) لمراقبة نسبة الامتلاء.",
    failureDiagnostics:
      "توقف التجديد نتيجة الرحلات القصيرة المتكررة يسبب انسداد DPF وتقليص عزم المحرك (Limp Mode)، وتراكم السناج في صمام EGR يسبب تقطيعاً في المحرك.",
    imagePrompt:
      "Cutaway scientific CAD diagram of a diesel exhaust aftertreatment unit showing honeycomb Silicon Carbide DPF substrate, catalytic converter, and water-cooled EGR heat exchanger.",
  },
  {
    id: "fuel-tank",
    assemblyId: "exhaust_fuel",
    partCode: "FUL-TNK-75L",
    nameAr: "خزان الوقود (75 لتر) ومستشعرات الضغط",
    nameEn: "75L Protected Underbody Fuel Tank & Dual-Stage Filtration",
    material: "بولي إيثيلين عالي الكثافة متعدد الطبقات (HDPE) أو فولاذ مجلفن مع درع سفلي",
    operatingSpecs: "السعة: 75 لتر · فلتر رئيسي: 2–5 ميكرون مع فاصل ماء",
    scientificPrinciple:
      "يحتوي الخزان على حواجز داخلية (Baffles) لتخميد حركة الموجات السائلة (Fluid Sloshing) ومنع انكشاف مدخل السحب عند صعود المنحدرات الحادة. ويستخدم فلتر الوقود حاجزاً كارهًا للماء (Hydrophobic Media) لفصل قطرات الماء المكثف عن الديزل بفرق الكثافة ($ρ_{water}=1.0 > ρ_{diesel}=0.835$) حمايةً لحاقنات 2000 بار.",
    equation: "ΔP_hydrostatic = (ρ_water - ρ_diesel) · g · h",
    equationLegend: "ترسب الماء في قاع الفلتر وتنبيه السائق عبر حساس العوامة عند ارتفاع منسوبه",
    mechanicalInteraction:
      "يُثبّت الخزان بأحزمة فولاذية داخل تجويف الشاصي الأيسر بعيداً عن أنبوب العادم الساخن، ويتصل بخطوط الإمداد والراجع المبردة.",
    failureDiagnostics:
      "دخول ماء أو شوائب عبر فلتر تجاري غير مطابق يدمر مضخة الضغط العالي خلال ساعات معدودة.",
    imagePrompt:
      "Technical cutaway rendering of a 75-liter underbody truck fuel tank showing internal anti-slosh baffles, fuel level sender, and primary diesel water-separator filter housing.",
  },

  // 08. BODY, CAB, ELECTRICAL & WHEELS
  {
    id: "bdy-rise-cab",
    assemblyId: "body_wheels",
    partCode: "BDY-RISE-DCAB",
    nameAr: "هيكل المقصورة المزدوجة (RISE Safety Body)",
    nameEn: "RISE Reinforced Impact Safety Evolution Double Cab",
    material: "صفائح فولاذ عالي الشد (440–980 MPa) بأعمدة A/B معززة",
    operatingSpecs: "معامل السحب الهوائي: Cd ≈ 0.40 · طول قاعدة العجلات: 3,000 ملم",
    scientificPrinciple:
      "تطبق بنية RISE مناطق انهيار أمامية وخلفية مدروسة لتشتيت طاقة التصادم، محيطةً بخلية ركاب عالية الصلابة تحافظ على الحيز البقائي. كما صُمّم انحدار الزجاج الأمامي والخط الفاصل بين المقصورة والصندوق لتقليل الدوامات الهوائية الخلفية وخفض معامل السحب ($F_D = \frac{1}{2}\rho v^2 C_d A$).",
    equation: "F_drag = ½ · ρ_air · v² · C_d · A_frontal",
    equationLegend: "خفض Cd إلى 0.40 يقلل استهلاك الوقود على الطرق السريعة حيث تتناسب المقاومة الهوائية مع مربع السرعة",
    mechanicalInteraction:
      "ترتكز المقصورة على 8 وسائد مطاطية فوق الشاصي ومفصولة عن الصندوق الخلفي بفاصل هيكلي مرن لمنع تمزق الصفائح عند التواء الشاصي.",
    failureDiagnostics:
      "صرير الأبواب أو تسرب الهواء عند السرعات العالية ينتج عن هبوط وسائد المقصورة المطاطية أو تلف جلد العزل.",
    imagePrompt:
      "Architectural automotive wireframe and shaded CAD cutaway of a 2016 Mitsubishi L200 double cab body shell highlighting ultra-high-strength steel A/B pillars and impact load paths.",
  },
  {
    id: "bdy-ecu-elec",
    assemblyId: "body_wheels",
    partCode: "ELC-ECU-CAN",
    nameAr: "وحدة التحكم الإلكتروني (ECU) وشبكة CAN-Bus",
    nameEn: "DENSO Engine Control Unit, 130A Alternator & CAN Network",
    material: "لوحة إلكترونية محكمة الإغلاق (IP67) · ضفيرة نحاسية مجدولة",
    operatingSpecs: "ناقل بيانات CAN بسرعة 500 kbps · جهد 12V (14.2V شحن) · مولد 130 أمبير",
    scientificPrinciple:
      "يعالج كمبيوتر المحرك (ECU) بيانات حساسات الضغط ودرجة الحرارة وسرعة العمود المرفقي في دورات بالميللي ثانية باستخدام خرائط تحكم ثلاثية الأبعاد (Lookup Tables) لتحديد زمن الحقن وكميته وزاوية التوربو. تتواصل الوحدات (ECU، ناقل الحركة، ABS، الدبل) عبر خطي إشارة تفاضلية (CAN-H و CAN-L) لمناعة تامة ضد التشويش الكهرومغناطيسي.",
    equation: "V_diff = V_CAN-H - V_CAN-L  (0V سائد / 2V مهيمن — إلغاء الضوضاء المشتركة)",
    equationLegend: "الإشارة التفاضلية المجدولة تحمي البيانات الحرجة من حقول الإشعال والمولد الكهرومغناطيسية",
    mechanicalInteraction:
      "يستمد الكهرباء من البطاريتين (في المواصفات الباردة) والمولد الذي يشغل أيضاً مضخة التفريغ (Vacuum Pump) المتصلة بباكم الفرامل.",
    failureDiagnostics:
      "سقوط أحد أسلاك CAN يظهر أخطاء اتصال (U0100/U0101) وتوقف عدة عدادات معاً في لوحة القيادة.",
    imagePrompt:
      "Technical macro CAD visualization of an automotive engine control unit (ECU) PCB inside a finned aluminum housing alongside a 130A copper-wound alternator and twisted-pair CAN-bus wiring harness.",
  },
  {
    id: "bdy-wheels",
    assemblyId: "body_wheels",
    partCode: "WHL-17-245AT",
    nameAr: "العجلات والإطارات (245/65R17) والديناميكا الاحتكاكية",
    nameEn: "17-Inch Alloy Rims & All-Terrain Radial Tires",
    material: "جنوط سبيكة ألومنيوم A356-T6 · مطاط معزز بالسيليكا وأحزمة فولاذية",
    operatingSpecs: "المقاس: 245/65R17 · القطر الخارجي: 750 ملم · الضغط القياسي: 2.0–2.4 bar",
    scientificPrinciple:
      "ينقل الإطار جميع قوى التسارع والكبح والانعطاف عبر رقعة التماس (Contact Patch) التي تتبع نموذج الاحتكاك المرن-اللزج (Hysteresis & Adhesion). في الرمال والطرق الوعرة، يؤدي خفض ضغط الإطار إلى ~1.2 bar لزيادة طول رقعة التماس بنسبة 60% وخفض الضغط السطحي ($P = W / A_{patch}$) دون غوص الإطار.",
    equation: "P_ground ≈ P_tire + P_carcass  ⇒  ↓P_tire  ⟹  ↑A_contact_patch",
    equationLegend: "تقليل ضغط الهواء يوزع وزن الـ 1.9 طن على مساحة رمل أكبر فيضاعف قوة الجر",
    mechanicalInteraction:
      "تثبت كل عجلة بـ 6 صواميل بقطر دائرة مسامير 6×139.7 ملم مباشرة على صرة الهوب الأمامي أو العكس الخلفي.",
    failureDiagnostics:
      "التآكل المسنن (Cupping) يشير لضعف المساعدات، بينما تآكل الحافتين معاً يعني انخفاض ضغط الهواء المزمن.",
    imagePrompt:
      "Clean technical cutaway of an off-road 17-inch 6-spoke aluminum alloy wheel and radial all-terrain tire showing internal steel belts, carcass plies, and deep tread blocks.",
  },
];
