import React, { useState } from "react";
import { Box, Camera, Check, Copy, FileDown, FolderArchive, Search } from "lucide-react";
import {
  AssemblyId,
  GENERATED_GALLERY_IMAGES,
  L200_ASSEMBLIES,
  SCIENTIFIC_PARTS,
  ScientificPart,
  VEHICLE_OVERVIEW_SPECS,
} from "../data/l200Data";

interface FullBreakdownViewProps {
  onInspectIn3D: (assemblyId: AssemblyId, partId: string) => void;
  onGenerateImageForPart: (part: ScientificPart) => void;
}

export const FullBreakdownView: React.FC<FullBreakdownViewProps> = ({
  onInspectIn3D,
  onGenerateImageForPart,
}) => {
  const [filterAssembly, setFilterAssembly] = useState<AssemblyId | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});
  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyLink = async () => {
    const targetUrl =
      window.location.origin.startsWith("http")
        ? window.location.origin
        : "https://ais-pre-nd352h7rsvuroujv5xaxe5-68197029196.europe-west2.run.app";
    try {
      await navigator.clipboard.writeText(targetUrl);
      setCopiedLink(true);
      window.setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(false);
    }
  };

  const handleDownloadStandaloneHtml = () => {
    const escapeHtml = (str: string) =>
      str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");

    const sectionsHtml = L200_ASSEMBLIES.map((asm) => {
      const parts = SCIENTIFIC_PARTS.filter((p) => p.assemblyId === asm.id);
      const partsHtml = parts
        .map(
          (p) => `
          <article class="part">
            <div class="meta"><span>${escapeHtml(p.partCode)}</span> · <span dir="ltr">${escapeHtml(p.nameEn)}</span></div>
            <h3>${escapeHtml(p.nameAr)}</h3>
            <p class="specs"><strong>المادة الهندسية:</strong> ${escapeHtml(p.material)}<br/><strong>حدود التشغيل:</strong> ${escapeHtml(p.operatingSpecs)}</p>
            <p>${escapeHtml(p.scientificPrinciple)}</p>
            <pre dir="ltr" class="eq">${escapeHtml(p.equation)}</pre>
            <p class="legend">${escapeHtml(p.equationLegend)}</p>
            <p><strong>الربط الميكانيكي:</strong> ${escapeHtml(p.mechanicalInteraction)}</p>
            <p><strong>التشخيص والأعطال:</strong> ${escapeHtml(p.failureDiagnostics)}</p>
          </article>`
        )
        .join("\n");

      return `
        <section class="assembly">
          <h2>${escapeHtml(asm.indexLabel)}. ${escapeHtml(asm.nameAr)} <small>(${escapeHtml(asm.massEstimateKg.toString())} kg)</small></h2>
          <p class="summary">${escapeHtml(asm.summaryAr)}</p>
          ${partsHtml}
        </section>`;
    }).join("\n");

    const htmlDoc = `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>موسوعة تفكيك ميتسوبيشي L200 (2016) — التقرير العلمي الكامل</title>
  <style>
    body { font-family: system-ui, -apple-system, "Segoe UI", Tahoma, sans-serif; background: #0b0f14; color: #e2e8f0; margin: 0; padding: 32px 20px; line-height: 1.75; }
    .wrap { max-width: 960px; margin: 0 auto; position: relative; }
    .wm-header { display: flex; align-items: center; gap: 14px; border-bottom: 1px solid rgba(255,255,255,0.12); padding-bottom: 14px; }
    .wm-logo { width: 56px; height: 56px; object-fit: contain; }
    h1 { color: #ffffff; margin: 0; font-size: 1.55rem; }
    h2 { color: #f87171; margin-top: 36px; font-size: 1.3rem; }
    h3 { color: #ffffff; margin: 8px 0; font-size: 1.08rem; }
    .summary { color: #94a3b8; }
    .part { background: #111722; border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 18px; margin: 16px 0; }
    .meta { font-size: 0.82rem; color: #fbbf24; font-family: monospace; }
    .specs { background: #0b0f14; padding: 10px 12px; border-radius: 8px; font-size: 0.9rem; color: #cbd5e1; }
    .eq { background: #0b0f14; border: 1px solid rgba(255,255,255,0.08); padding: 10px 12px; border-radius: 8px; color: #fcd34d; overflow-x: auto; font-family: monospace; }
    .legend { font-size: 0.84rem; color: #94a3b8; margin-top: -6px; }
    @media print { body { background: #fff; color: #111; } .part, .specs, .eq { background: #f8fafc; color: #111; border-color: #cbd5e1; } h1, h3 { color: #000; } h2 { color: #b91c1c; } .wm-logo { filter: invert(1); opacity: 0.85; } }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="wm-header">
      <img class="wm-logo" src="https://ais-pre-nd352h7rsvuroujv5xaxe5-68197029196.europe-west2.run.app/assets/aistudio/logo_white.png" alt="الشعار الرسمي" />
      <h1>موسوعة التفكيك العلمي والفيزيائي لسيارة ميتسوبيشي L200 (موديل 2016)</h1>
    </div>
    ${sectionsHtml}
  </div>
</body>
</html>`;

    const blob = new Blob([htmlDoc], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "mitsubishi-l200-2016-encyclopedia.html";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const filteredParts = SCIENTIFIC_PARTS.filter((part) => {
    const matchesAsm = filterAssembly === "all" || part.assemblyId === filterAssembly;
    const q = searchQuery.trim().toLowerCase();
    const matchesQuery =
      !q ||
      part.nameAr.toLowerCase().includes(q) ||
      part.nameEn.toLowerCase().includes(q) ||
      part.partCode.toLowerCase().includes(q) ||
      part.scientificPrinciple.toLowerCase().includes(q) ||
      part.material.toLowerCase().includes(q);
    return matchesAsm && matchesQuery;
  });

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-10">
      {/* Hero Split: Engineering Cutaway + Core Specifications */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-7 bg-[#111722] border border-white/10 rounded-xl overflow-hidden flex flex-col">
          <div className="relative aspect-video lg:flex-1 bg-[#0B0F14] overflow-hidden">
            {!brokenImages["hero"] ? (
              <img
                src={GENERATED_GALLERY_IMAGES.heroCutaway}
                alt="مقطع تشريحي هندسي لسيارة ميتسوبيشي L200 موديل 2016"
                referrerPolicy="no-referrer"
                onError={() => setBrokenImages((b) => ({ ...b, hero: true }))}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-950 text-slate-400 text-sm">
                مخطط التفكيك الهندسي — Mitsubishi L200 (2016)
              </div>
            )}
            <img
              src="/assets/aistudio/logo_white.png"
              alt="العلامة المائية الرسمية"
              referrerPolicy="no-referrer"
              className="pointer-events-none absolute top-3 left-3 w-16 h-16 sm:w-20 sm:h-20 object-contain opacity-85 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent flex flex-col justify-end p-5">
              <div className="text-xs text-slate-300 mb-1">
                الجيل الخامس KL/KK · بنية RISE · دفع رباعي Super Select 4WD-II
              </div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-white">
                التشريح العلمي والفيزيائي الكامل لسيارة ميتسوبيشي L200 (2016)
              </h1>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 bg-[#111722] border border-white/10 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img
                src="/assets/aistudio/logo_white.png"
                alt="الشعار الرسمي للموسوعة"
                referrerPolicy="no-referrer"
                className="w-10 h-10 object-contain shrink-0"
              />
              <h2 className="text-base font-bold text-white">
                البطاقة الهندسية المرجعية للمركبة
              </h2>
            </div>
            <dl className="divide-y divide-white/8 text-xs">
              {VEHICLE_OVERVIEW_SPECS.map((spec) => (
                <div
                  key={spec.label}
                  className="py-2.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1"
                >
                  <dt className="text-slate-400 shrink-0">{spec.label}</dt>
                  <dd className="text-slate-100 font-medium font-mono-tech text-left">
                    {spec.value}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="pt-4 mt-4 border-t border-white/8 space-y-3">
            <div className="text-xs text-slate-400 leading-relaxed">
              يشمل هذا التفكيك 8 منظومات رئيسية و{SCIENTIFIC_PARTS.length} مكوناً ميكانيكياً
              وفيزيائياً مع تحليل المعادلات الحاكمة، السبيكة المعدنية، وتشخيص الأعطال.
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>تم نسخ رابط الموسوعة</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-sky-400" />
                    <span>نسخ رابط الموسوعة</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleDownloadStandaloneHtml}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-600/20 hover:bg-red-600/30 border border-red-500/40 text-xs font-medium text-red-100 transition-colors"
              >
                <FileDown className="w-3.5 h-3.5 text-red-400" />
                <span>تنزيل الموسوعة (HTML مستقل)</span>
              </button>
              <a
                href="/api/download-zip"
                download="mitsubishi-l200-2016-source.zip"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/40 text-xs font-medium text-amber-100 transition-colors"
              >
                <FolderArchive className="w-3.5 h-3.5 text-amber-400" />
                <span>تنزيل ملفات المشروع (ZIP)</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Filter & Search Toolbar */}
      <section className="space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setFilterAssembly("all")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                filterAssembly === "all"
                  ? "bg-red-600 text-white border-red-500"
                  : "bg-[#111722] text-slate-300 border-white/10 hover:text-white"
              }`}
            >
              جميع المنظومات ({SCIENTIFIC_PARTS.length})
            </button>
            {L200_ASSEMBLIES.map((asm) => (
              <button
                key={asm.id}
                type="button"
                onClick={() => setFilterAssembly(asm.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                  filterAssembly === asm.id
                    ? "bg-red-600 text-white border-red-500"
                    : "bg-[#111722] text-slate-300 border-white/10 hover:text-white"
                }`}
              >
                {asm.indexLabel}. {asm.nameAr.split("(")[0].trim()}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-72 shrink-0">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن قطعة أو معادلة أو سبيكة..."
              className="w-full bg-[#111722] border border-white/12 rounded-lg pr-9 pl-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-red-500"
            />
          </div>
        </div>

        {/* Visual Cutaway Reference Strip */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            {
              key: "engine",
              img: GENERATED_GALLERY_IMAGES.engine4n15,
              title: "01. محرك 4N15 2.4L MIVEC والتوربو VGT",
              sub: "كتلة ألومنيوم · حقن مشترك 2000 بار · تبريد بيني",
              asmId: "engine" as AssemblyId,
            },
            {
              key: "drivetrain",
              img: GENERATED_GALLERY_IMAGES.drivetrain4wd,
              title: "02. ناقل الحركة وعلبة Super Select 4WD-II",
              sub: "تفاضل وسطي لزج · تخفيض 2.566:1 · قفل دفرنس خلفي",
              asmId: "drivetrain" as AssemblyId,
            },
            {
              key: "chassis",
              img: GENERATED_GALLERY_IMAGES.chassisSuspension,
              title: "03. شاصي RISE والتعليق المزدوج والسست",
              sub: "فولاذ عالي الشد 590 MPa · مقصات مزدوجة · أقراص 294mm",
              asmId: "chassis" as AssemblyId,
            },
          ].map((card) => (
            <button
              key={card.key}
              type="button"
              onClick={() => setFilterAssembly(card.asmId)}
              className="text-right bg-[#111722] border border-white/10 hover:border-white/25 rounded-xl overflow-hidden transition-colors group"
            >
              <div className="relative aspect-[4/3] bg-[#0B0F14] overflow-hidden">
                {!brokenImages[card.key] ? (
                  <img
                    src={card.img}
                    alt={card.title}
                    referrerPolicy="no-referrer"
                    onError={() =>
                      setBrokenImages((b) => ({ ...b, [card.key]: true }))
                    }
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">
                    {card.title}
                  </div>
                )}
                <img
                  src="/assets/aistudio/logo_white.png"
                  alt=""
                  referrerPolicy="no-referrer"
                  className="pointer-events-none absolute bottom-2.5 left-2.5 w-14 h-14 object-contain opacity-85 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]"
                />
              </div>
              <div className="p-4">
                <h3 className="text-sm font-bold text-white">{card.title}</h3>
                <p className="text-xs text-slate-400 mt-1">{card.sub}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Scientific Part Cards Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredParts.length === 0 ? (
          <div className="lg:col-span-2 p-10 text-center bg-[#111722] border border-white/10 rounded-xl text-sm text-slate-400">
            لا توجد قطع مطابقة لبحثك. جرّب مسح نص البحث أو اختيار جميع المنظومات.
          </div>
        ) : (
          filteredParts.map((part) => {
            const asm = L200_ASSEMBLIES.find((a) => a.id === part.assemblyId)!;
            return (
              <article
                key={part.id}
                className="bg-[#111722] border border-white/10 rounded-xl p-6 flex flex-col justify-between gap-5"
              >
                <div className="space-y-4">
                  {/* Quiet inline metadata (Zero-Pill Rule) */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
                    <div>
                      <span>
                        {asm.indexLabel}. {asm.nameAr.split("(")[0].trim()}
                      </span>
                      <span aria-hidden="true" className="mx-1.5">
                        ·
                      </span>
                      <span className="font-mono-tech text-amber-400">
                        {part.partCode}
                      </span>
                    </div>
                    <span dir="ltr" className="text-[11px] text-slate-500">
                      {part.nameEn}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white">{part.nameAr}</h3>

                  <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3.5 text-xs space-y-1.5">
                    <div>
                      <span className="text-slate-400">المادة الهندسية: </span>
                      <span className="text-slate-200">{part.material}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">بيانات التشغيل: </span>
                      <span className="text-sky-300 font-mono-tech">
                        {part.operatingSpecs}
                      </span>
                    </div>
                  </div>

                  <p className="text-sm text-slate-200 leading-relaxed">
                    {part.scientificPrinciple}
                  </p>

                  <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3.5 space-y-1">
                    <div
                      dir="ltr"
                      className="font-mono-tech text-xs text-amber-300 overflow-x-auto"
                    >
                      {part.equation}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {part.equationLegend}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-white/8 text-xs leading-relaxed">
                    <div>
                      <div className="font-semibold text-slate-200 mb-1">
                        الربط الميكانيكي
                      </div>
                      <p className="text-slate-400">{part.mechanicalInteraction}</p>
                    </div>
                    <div>
                      <div className="font-semibold text-slate-200 mb-1">
                        التشخيص والأعطال
                      </div>
                      <p className="text-slate-400">{part.failureDiagnostics}</p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 pt-3 border-t border-white/8">
                  <button
                    type="button"
                    onClick={() => onInspectIn3D(part.assemblyId, part.id)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors"
                  >
                    <Box className="w-3.5 h-3.5 text-sky-400" />
                    <span>معاينة في النموذج ثلاثي الأبعاد</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onGenerateImageForPart(part)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-red-600/20 hover:bg-red-600/30 border border-red-500/40 text-xs font-medium text-red-100 transition-colors"
                  >
                    <Camera className="w-3.5 h-3.5 text-red-400" />
                    <span>توليد صورة علمية (1K / 2K / 4K)</span>
                  </button>
                </div>
              </article>
            );
          })
        )}
      </section>
    </div>
  );
};
