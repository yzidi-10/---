import "dotenv/config";
import express from "express";
import type { Request, Response } from "express";
import path from "path";
import os from "os";
import fs from "fs";
import { execFile } from "child_process";
import { promisify } from "util";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";

const execFileAsync = promisify(execFile);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "4mb" }));

  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ status: "ok", vehicle: "Mitsubishi L200 2016 (KL/KK)" });
  });

  app.post("/api/generate-image", async (req: Request, res: Response) => {
    try {
      const { prompt, imageSize = "1K", aspectRatio = "16:9" } = req.body ?? {};
      if (!prompt || typeof prompt !== "string") {
        res.status(400).json({ error: "يرجى إدخال وصف هندسي صحيح للصورة المطلوبة." });
        return;
      }

      const validSizes = ["1K", "2K", "4K"] as const;
      const resolvedSize = validSizes.includes(imageSize) ? imageSize : "1K";
      const validRatios = ["1:1", "3:4", "4:3", "9:16", "16:9"] as const;
      const resolvedRatio = validRatios.includes(aspectRatio) ? aspectRatio : "16:9";

      const ai = getGeminiClient();
      if (!ai) {
        res.status(503).json({
          error:
            "مفتاح GEMINI_API_KEY غير مهيأ على الخادم. يرجى ضبط المفتاح في لوحة Settings > Secrets لتفعيل التوليد المباشر عبر gemini-3-pro-image-preview.",
          requiresPaidKey: true,
        });
        return;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-pro-image-preview",
        contents: {
          parts: [
            {
              text: prompt,
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: resolvedRatio,
            imageSize: resolvedSize,
          },
        },
      });

      let imageDataUrl: string | null = null;
      let captionText = "";

      for (const part of response.candidates?.[0]?.content?.parts ?? []) {
        if (part.inlineData?.data) {
          const mime = part.inlineData.mimeType ?? "image/png";
          imageDataUrl = `data:${mime};base64,${part.inlineData.data}`;
        } else if (part.text) {
          captionText += part.text;
        }
      }

      if (!imageDataUrl) {
        res.status(502).json({
          error: "لم يُرجع النموذج صورة صالحة. يرجى تعديل الوصف والمحاولة مرة أخرى.",
        });
        return;
      }

      res.json({
        imageDataUrl,
        caption: captionText,
        model: "gemini-3-pro-image-preview",
        imageSize: resolvedSize,
        aspectRatio: resolvedRatio,
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      const isQuotaOrPermission =
        /403|429|PERMISSION_DENIED|RESOURCE_EXHAUSTED|API_KEY_INVALID|billing/i.test(message);

      res.status(isQuotaOrPermission ? 403 : 500).json({
        error: isQuotaOrPermission
          ? "يتطلب نموذج gemini-3-pro-image-preview مفتاح API مفعل عليه الفوترة (Paid Tier) في Settings > Secrets."
          : `تعذر توليد الصورة الهندسية: ${message}`,
        requiresPaidKey: isQuotaOrPermission,
      });
    }
  });

  app.post("/api/explain-part", async (req: Request, res: Response) => {
    try {
      const { partName, subsystem, question } = req.body ?? {};
      if (!partName || !question) {
        res.status(400).json({ error: "اسم القطعة والسؤال الهندسي مطلوبان." });
        return;
      }

      const ai = getGeminiClient();
      if (!ai) {
        res.status(503).json({
          error: "مفتاح GEMINI_API_KEY غير متوفر على الخادم حالياً.",
        });
        return;
      }

      const response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: `المركبة: ميتسوبيشي L200 (Triton) الجيل الخامس موديل 2016.
المنظومة: ${subsystem ?? "عام"}
القطعة المحددة: ${partName}
سؤال المستخدم العلمي: ${question}`,
        config: {
          systemInstruction:
            "أنت مهندس ميكانيك سيارات وباحث في الديناميكا الحرارية والميتالورجيا متخصص في شاحنة ميتسوبيشي L200 موديل 2016 (محركات 4N15 MIVEC 2.4L و4D56 ونظام Super Select 4WD-II وشاصي RISE). أجب باللغة العربية العلمية الدقيقة والمنظمة: اشرح المبدأ الفيزيائي، المواد الهندسية، التفاعل مع الأجزاء المجاورة، والمعادلات ذات الصلة بإيجاز واحترافية دون حشو.",
        },
      });

      res.json({
        answer: response.text ?? "لم يتم استلام رد من المحرك العلمي.",
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(500).json({
        error: `تعذر إتمام التحليل العلمي: ${message}`,
      });
    }
  });

  app.get("/api/download-zip", async (_req: Request, res: Response) => {
    const tmpZip = path.join(os.tmpdir(), `l200-2016-${Date.now()}.zip`);
    const pyScript = `
import os, sys, zipfile
root = sys.argv[1]
out_zip = sys.argv[2]
skip_dirs = {"node_modules", "dist", ".git", ".aistudio", ".next"}
skip_files = {".env"}
with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]
        for fname in filenames:
            if fname in skip_files:
                continue
            full = os.path.join(dirpath, fname)
            rel = os.path.relpath(full, root)
            zf.write(full, rel)
`;
    try {
      await execFileAsync("python3", ["-c", pyScript, __dirname, tmpZip]);
      res.download(tmpZip, "mitsubishi-l200-2016-source.zip", (err) => {
        fs.unlink(tmpZip, () => {});
        if (err && !res.headersSent) {
          res.status(500).json({ error: "تعذر إرسال ملف ZIP." });
        }
      });
    } catch (err: unknown) {
      fs.unlink(tmpZip, () => {});
      const message = err instanceof Error ? err.message : String(err);
      res.status(500).json({ error: `تعذر إنشاء ملف ZIP: ${message}` });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
